package com.example.projectattempt1;

public class MovingBar {
	public float x;
	public float y;
	public boolean alive = true;
	public int width = 229;
	public int height = 25;
	
	public MovingBar(float xPos, float yPos){
		x = xPos;
		y = yPos;
	}
	
}
