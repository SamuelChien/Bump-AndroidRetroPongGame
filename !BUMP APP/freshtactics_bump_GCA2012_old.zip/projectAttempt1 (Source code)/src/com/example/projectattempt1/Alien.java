package com.example.projectattempt1;

import android.R.integer;

public class Alien {
  public int color, timer, xPos, yPos;
  public boolean isAlive;
  public int width =  60;
  public int height = 65;
  public int enemyrow;
  
  public Alien (int colorpass, boolean isAlivepass, int timerpass, int xPospass, int yPospass){

    color = colorpass;
    isAlive = isAlivepass;
    timer = timerpass;
    xPos = xPospass;
    yPos = yPospass;

  }
  
}